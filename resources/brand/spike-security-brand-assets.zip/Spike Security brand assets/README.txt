SPIKE SECURITY BRAND ASSETS
Brand guidelines: https://www.spikesecurity.co.uk/branding

WHICH LOGO FILE?
  On a dark background ........ logo/spike-security-horizontal-dark
  On a white or light page .... logo/spike-security-horizontal-light
  One colour print ............ -orange, -bone or -obsidian versions
  Square spaces, signs ........ logo/spike-security-stacked-*
  Favicons, app icons ......... logo/spike-security-shield-*
  Files ending -bg.png include the background colour.

FORMATS
  SVG and PDF are vector: use them for print, signs and embroidery.
  PNG is for documents, slides and the web. Never stretch or recolour the logo.

SIGNS AND UNIFORMS
  Sign PDFs are A3 with 3 mm bleed on every edge (page 303 x 426 mm); trim to A3.
  Uniform inks: Pantone Orange 021 C for the shield, white ink for bone lettering.

EMAIL
  email/ holds the two images the signature builder on the brand page links to.

COLOURS
  Obsidian      #0B0C0E   background
  Spike Orange  #FF5B1A   the shield (nearest spot colour: Pantone Orange 021 C, check against a swatch)
  Bone          #EEEAE0   text on dark, light surfaces
  Ember         #B33A06   orange text on light backgrounds

FONTS
  Archivo for words. Martian Mono, at 87.5% width, for the numbers people
  dial, check or copy: the phone number, times, references, licence and
  company numbers, colour values. Both are free under the SIL Open Font
  License, in the font folder. Without them: Arial for words, Consolas for
  numbers. Email signatures always use Arial.

Questions: info@spikesecurity.co.uk · 020 3757 2767
